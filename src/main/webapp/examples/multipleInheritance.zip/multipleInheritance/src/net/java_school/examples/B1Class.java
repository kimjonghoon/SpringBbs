package net.java_school.examples;

public class B1Class {
    public String hello() {
        return "B1 Class says hello";
    }
}