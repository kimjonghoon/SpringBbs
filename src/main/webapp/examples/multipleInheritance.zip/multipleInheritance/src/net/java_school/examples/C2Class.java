package net.java_school.examples;

public class C2Class implements B2Interface,A2Interface {

}