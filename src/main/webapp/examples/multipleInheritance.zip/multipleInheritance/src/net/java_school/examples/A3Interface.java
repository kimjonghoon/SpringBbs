package net.java_school.examples;

public interface A3Interface {
    public default String hello() {
        return "A3 Interface says hello";
    }
}