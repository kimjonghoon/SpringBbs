package net.java_school.examples;

public interface A2Interface {
    public default String hello() {
        return "A2 Interface says hello";
    }
}