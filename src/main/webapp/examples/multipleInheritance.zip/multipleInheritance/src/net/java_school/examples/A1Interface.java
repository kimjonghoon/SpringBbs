package net.java_school.examples;

public interface A1Interface {
    public default String hello() {
        return "A1 Interface says hello";
    }
}