package net.java_school.examples;

public class C1Class extends B1Class implements A1Interface {

}