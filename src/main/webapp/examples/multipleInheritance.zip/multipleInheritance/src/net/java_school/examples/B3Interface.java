package net.java_school.examples;

public interface B3Interface {
    public default String hello() {
        return "B3 Interface says hello";
    }
}