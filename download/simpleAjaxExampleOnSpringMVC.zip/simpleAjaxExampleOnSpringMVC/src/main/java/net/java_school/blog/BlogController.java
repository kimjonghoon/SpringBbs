package net.java_school.blog;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class BlogController {

	@RequestMapping(method=RequestMethod.GET)
	public String home() {
		return "index";
	}

	@RequestMapping(value="java", method=RequestMethod.GET)
	public String javaIndex() {
		return "java/index";
	}

	@RequestMapping(value="java/{id}", method=RequestMethod.GET)
	@ResponseBody
	public Post getPost(@PathVariable String id) {
		Post post = new Post();

		switch (id) {
		case "jdk-install":
			post.setTitle("자바 설치");
			post.setKeywords("JDK,Java 8");
			post.setDescription("자바 8 설치에 대해 설명합니다.");
			post.setContent("http://www.oracle.com을 방문합니다. ..");
			break;
		default:
			post.setTitle("해당 문서가 없습니다.");
			post.setKeywords("해당 문서가 없습니다.");
			post.setDescription("해당 문서가 없습니다.");
			post.setContent("해당 문서가 없습니다.");
		}

		return post;
	}

}